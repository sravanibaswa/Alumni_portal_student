 <HTML>
<head>
<title>Student page</title>
<style>
.img1{
margin-top:100px;
margin-left:50px;
padding:80px;
} 
08:26 01-12-2020
form {
  align:center;
  padding: 120px;
   
  }
button {
  background-color:green;
  color: white;
  padding: 8px 20px;
  margin: 8px 0;
  border: black 1px;
  cursor: pointer;
  border-radius:10px;
   
}
body{
background-image:url("home-imgs.jpg");
background-repeat:no-repeat;
background-size:1800px 800px;
} 
.img1 img {
	border: 5px solid black;
   width: 180px;
  height: 150px;
  object-fit: contain;
  border-radius:20%;
}
/* Add a black background color to the top navigation */
.topnav {
  background-color: #333;
  overflow: hidden;
}

/* Style the links inside the navigation bar */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

/* Change the color of links on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Add a color to the active/current link */
.topnav a.active {
  background-color: #4CAF50;
  color: white;
}
.topnav button{
   
  float: right;
  padding:6px;
  margin-top:-30px;
  margin-right:25px;
  border-radius:10px;
  background:green;
  font-size: 17px;
  border: none;
  cursor: pointer;

}
.topnav input[type=text]{
   
   padding:6px;
  margin-top: -30px;
  margin-left:1075px;
  border: none;
  border-radius:10px;
}
button {
  background-color:green;
  color: white;
  padding: 8px 20px;
  margin: 8px 0;
  border: black 1px;
  cursor: pointer;
  border-radius:10px;
   
} 
font{
padding:8px 0px;

}
 

 
.blink {
	font-family:Lucida Console;
	font-size:2em;
  animation: blink 1s steps(1, end) infinite;
}

@keyframes blink {
  0% {
    opacity: 1;
	 text-color:green;	 
  }
  50% {
    opacity: 0;
	text-color:red;
  }
  100% {
    opacity: 1;
	text-color:green;
  }
}
 
 
 </style>
</head>
<body bgcolor=black>
 <div class="topnav">
  <a class="home" href="index.html">Home</a>
  <a href="responses.php">View Responses</a>
  <a href="sitemap.html">Sitemap</a>
  <a href="about.html">About</a>
 
</div>

 <h3><center><font color=red>A.V.C COLLEGE OF ENGINEERING</CENTER></H3>
<H4><CENTER>DEPARTMENT OF INFORMATION TECHNOLOGY</font></H4></center>
<center>
<div class=blink>
<font  ><b>WELCOME STUDENT</b></font> </div></center>
<div class="img1">
<a href="job_view.php" color=white><img src="jobs.png" ></img></a> 
&emsp;
<a href= "intern_view.php"><img src="intern.png" ></img></a>&emsp;
<a href="inplant_view.php"><img src="inplant.png"></img></a> &emsp;
<a href="higher_view.php"><img src="higher.png"></img></a> &emsp;
<a href="request_ask.php"><img src="response.png"></img></a> &emsp;
 
<br> 
 &emsp;
<b>View Job Notification</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
<b>View Internship</b> &emsp;&emsp;&emsp;&emsp;
<b>View Inplant Training	</b>&emsp;&emsp;&emsp;	
<b>Higher Studies Advices</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
<b>Request</b>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
 
 
 </div>
 <div class="blink">
 
 </div>
 </body>
</htm